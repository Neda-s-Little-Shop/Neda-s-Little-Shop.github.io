---
title: "Behind the Scenes: Our Workshop"
date: 2024-03-10
featured_image: "images/cover.jpg"
categories: ["News"]
---

A third post to fill out the list view. This helps visualize pagination and card spacing.

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

<!--more-->

Extended content for the full post view.
