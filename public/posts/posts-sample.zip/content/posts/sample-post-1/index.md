---
title: "Getting Started with Handmade Crafts"
date: 2024-01-15
featured_image: "images/cover.jpg"
categories: ["Crafts"]
---

This is a sample post to test your layout. Replace this content with your actual writing.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.

<!--more-->

The rest of the content goes here after the summary break.
