---
title: "Summer Collection Preview"
date: 2024-02-20
featured_image: "images/cover.jpg"
categories: ["Collections"]
---

Another sample post for testing. The card layout should display this summary text alongside the featured image.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent euismod ultrices ante, ac laoreet nulla vestibulum vel.

<!--more-->

Full article content appears here.
